<!-- Top Selling By Revenue Shimmer -->
<div class="relative border rounded-xl bg-white py-5 px-[30px]">
    <!-- Header -->
    <div class="mb-4 flex items-center justify-between">
        <div class="shimmer h-7 w-80"></div>

        <div class="shimmer h-6 w-20"></div>
    </div>
    
    <!-- Progrss Bar Shimmer -->
    <x-marketplace::seller.shimmer.reporting.progress-bar />
</div>