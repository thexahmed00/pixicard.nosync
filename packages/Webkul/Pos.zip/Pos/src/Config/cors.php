<?php

return [
    'graphql',
];
