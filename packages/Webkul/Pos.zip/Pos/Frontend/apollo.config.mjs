export default {
    client: {
        service: {
            name: 'pos-frontend',
            url: 'http://localhost/2.2.2/headless-pos/public/graphql',
        },

        includes: [
            'src/**/*.vue',
            'src/**/*.js',
        ],
    },
};
