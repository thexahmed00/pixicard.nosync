import { defineConfig, loadEnv } from 'vite';
import vue from '@vitejs/plugin-vue';
import fs from 'fs';
import { fileURLToPath, URL } from 'node:url';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, process.cwd(), '');

    return {
        build: {
            OutDir: 'dist',
        },

        server: {
            host: env.VITE_HOST || 'localhost',
            port: Number(env.VITE_PORT) || 5174,
            https: env.VITE_SSL_ENABLED === 'true' ? {
                key: fs.readFileSync(env.VITE_SSL_KEY_PATH || 'path/to/your/private.crt'),
                cert: fs.readFileSync(env.VITE_SSL_CERT_PATH || 'path/to/your/certificate.crt'),
            } : false,
        },

        plugins: [vue()],
        
        resolve: {
            alias: {
                '@src': fileURLToPath(new URL('./src', import.meta.url)),
                '@components': fileURLToPath(new URL('./src/components', import.meta.url)),
                '@skeletons': fileURLToPath(new URL('./src/components/skeletons', import.meta.url)),
            },
        },
    };
});
